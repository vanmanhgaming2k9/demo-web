import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuGroup,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Menu } from "lucide-react";
import Link from "next/link";
import BrandToggle from "../brand-toggle";

// Navigation data
const navigationItems = [
    {
        id: "home",
        title: "Trang chủ",
        href: "/",
        isActive: true
    },
    {
        id: "services", 
        title: "Dịch vụ",
        href: "/services",
        isActive: false
    },
    {
        id: "contact",
        title: "Liên hệ", 
        href: "/contact",
        isActive: false
    }
];

export default function Navbar() {
    return (
        <header className="sticky top-0 z-50 flex h-16 items-center border-b bg-background backdrop-blur supports-[backdrop-filter]:bg-background/95">
            <div className="container flex items-center gap-4 md:gap-6">
                <Link
                    className="flex gap-1 sm:gap-[0.3125rem]"
                    style={{ WebkitTouchCallout: "none" }}
                    href="/"
                >
                    <BrandToggle />
                    <span className="sr-only">Vani Studio</span>
                </Link>
                <div className="flex-1" />
                
                {/* Desktop Navigation */}
                <div className="hidden md:flex">
                    <nav className="flex items-center gap-4 md:gap-6">
                        {navigationItems.map((item) => (
                            <Link
                                key={item.id}
                                className={`transition-colors hover:text-foreground ${
                                    item.isActive ? 'text-foreground' : 'text-muted-foreground'
                                }`}
                                title={item.title}
                                href={item.href}
                            >
                                {item.title}
                            </Link>
                        ))}
                    </nav>
                </div>
                
                {/* Mobile Navigation */}
                <nav className="flex items-center gap-2 md:gap-3">
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <button 
                                title="Menu" 
                                className="inline-flex items-center justify-center whitespace-nowrap text-base font-medium outline-none transition-[color,box-shadow] focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 disabled:pointer-events-none disabled:opacity-50 aria-[invalid=true]:border-destructive aria-[invalid=true]:ring-destructive/20 dark:aria-[invalid=true]:ring-destructive/40 [&_svg:not([class*='size-'])]:size-4 [&_svg]:pointer-events-none [&_svg]:shrink-0 border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground size-8 group flex-col gap-1 rounded-full md:hidden"
                            >
                                <Menu />
                            </button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent className="w-56" align="start">
                            <DropdownMenuGroup>
                                {navigationItems.map((item) => (
                                    <Link key={item.id} href={item.href}>
                                        <DropdownMenuItem>
                                            {item.title}
                                        </DropdownMenuItem>
                                    </Link>
                                ))}
                            </DropdownMenuGroup>
                        </DropdownMenuContent>
                    </DropdownMenu>
                </nav>
            </div>
        </header>
    );
}