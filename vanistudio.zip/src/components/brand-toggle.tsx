"use client";

import { useTheme } from "next-themes";
import { useEffect, useState } from "react";

export default function BrandToggle() {
    const { theme } = useTheme();
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        setMounted(true);
    }, []);
    if (!mounted) {
        return <img src="/vanistudio.png" alt="Vani Studio" className="h-10" />;
    }

    return (
        <>
            {theme === "dark" ? (
                <img src="/vanistudio.png" alt="Vani Studio" className="h-10" />
            ) : (
                <img src="/vanistudio.png" alt="Vani Studio" className="h-10" style={{ filter: "invert(1)" }} />
            )}
        </>
    );
}