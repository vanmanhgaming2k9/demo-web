import type { Metadata } from "next";
import { ThemeProvider } from "@/components/theme-provider"
import "./globals.css";
import Footer from "@/components/layouts/Footer";
import Navbar from "@/components/layouts/Navbar";

export const metadata: Metadata = {
  title: "Vani Studio - Dịch vụ phát triển phần mềm",
  description: "Vani Studio là tổ chức phát triển phần mềm chuyên về lập trình web, discord bot, và các dịch vụ liên quan đến phần mềm.",
  icons: {
    icon: "/vs.png",
  },
  openGraph: {
    images: "/vs.png",
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="vi" suppressHydrationWarning>
      <body>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <Navbar />
          {children}
          <Footer />
        </ThemeProvider>
      </body>
    </html>
  );
}
